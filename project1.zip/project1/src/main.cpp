#include "../include/Simulation.h"
#include "../include/FCFS.h"
#include "../include/RR.h"
#include "../include/PRIORITY.h"
#include "../include/CUSTOM.h"

#include <getopt.h>

using namespace std;

void option( int argc, char **argv, bool *eachThread, bool *verbose, string *algorithm, string *filename );
Planner* getPlan( string &algorithm );

int main( int argc, char** argv )
{
	bool everyThread( false ), verbose( false );
	string algorithm;
	string file;
	option( argc, argv, &everyThread, &verbose, &algorithm, &file );
	Print_Output* print_output = new Print_Output( verbose, everyThread );

	if( algorithm.empty() )
	{
		algorithm = "FCFS";
	}

	Planner* plan = getPlan( algorithm );

	if( !plan )
	{
		cout << "User input incorrect algorithm name: " << algorithm << endl;
		exit(-1);
	}

	Simulation simulation( plan, print_output );
	simulation.run( file );
	delete print_output;
	return 0;
}

void option( int argc, char **argv, bool *eachThread, bool *verbose, string *algorithm, string *filename )
{
	static struct option long_options[] = 
	{
		{ "eachThread",       no_argument, NULL, 't' },
		{    "verbose",       no_argument, NULL, 'v' },
		{  "algorithm",       no_argument, NULL, 'a' },
		{       "help",       no_argument, NULL, 'h' },
		{            0,                 0,    0,   0 },
	};

	while( true )
	{
		int option = 0;
		int flag_char = getopt_long( argc, argv, "tva:ch", long_options, &option );

		if( flag_char == -1 )
			break;

		switch( flag_char )
		{
			case 't':
				*eachThread = true;
				break;

			case 'v':
				*verbose = true;
				break;

			case 'a':
				*algorithm = string( optarg );
				break;

			case 'h':
				cout << "Instruction: ./cpu_scheduling_simulator [flags] [simulation_file]" << endl
					 << "         -t, --eachThread    Output additional per-thread statistics for arrival time, service time, etc." << endl
					 << "         -v, --verbose       Output information about every state-changing event and scheduling decision." << endl
					 << "         -a, --algorithm     The scheduling algorithm to use. One of FCFS, RR, PRIORITY, or CUSTOM." << endl
					 << "         -h, --help          Display a help message about these flags and exit." << endl;
				exit(0);
			case '?':
				break;
			default:
				exit(-1);
		}
	}

	if( optind + 1 < argc )
	{
		cout << "Incorrect flags" << endl;
		exit(-1);
	}

	if( optind >= argc )
	{
		cout << "Incorrect flags" << endl;
		exit(-1);
	}

	*filename = string(argv[optind]);
}

Planner* getPlan( string &algorithm )
{
	if( algorithm == "FCFS" )
	{
		return new FCFS();
	}
	else if( algorithm == "RR" )
	{
		return new RR();
	}
	else if( algorithm == "PRIORITY" )
	{
		return new PRIORITY();
	}
	else if( algorithm == "CUSTOM")
	{
		return new CUSTOM();
	}
	else
	{
		return NULL;
	}
}