#include "../include/FCFS.h"

using namespace std;

Choice* FCFS::get_next_thread( const Event* event )
{
	Thread *nextThread = NULL;

	if( !threads.empty() )
	{
		nextThread = threads.front();
		threads.pop();
	}

	char buffer[100];
	sprintf( buffer, "Selected from %u threads; will run to completion of burst", ( unsigned int ) threads.size() + 1 );
	string reason = string( buffer );

	Choice *choice = new Choice( nextThread, -1, reason );
	return choice;
}

void FCFS::enqueue( const Event* event, Thread* thread )
{
	threads.push( thread );
}